#ifndef AUTO_H
#define AUTO_H

#include "graph.h"

typedef struct Automate
{ 
	int init_st;

	int nb_finals;//Nb d'etat finaux
	int *finals_st;
	char *alphab;
	Graph *grph;
}Automate;

Automate* create_automate(int nb_st, char *alphab, int i_st, int* f_st, int nb_finals);

void free_autom(Automate* autom);
int states_add(Automate* autom, int e1, char ch, int e2);
void print_autom(Automate* autom);
int accept(Automate* autom, char* word);
int stateNextChar(Automate* autom, int s1, char e);
void Langage_croissant(Automate* autom);


#endif
