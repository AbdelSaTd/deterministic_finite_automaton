#ifndef FILE_H
#define FILE_H

typedef struct Cell{
    //int profond;
	char* word;
	int state;
    struct Cell *nxt;
} Cell;

typedef struct{
    Cell* head;
    Cell* bottom;
    int nbElts;
} Queue;


void init_queue(Queue** ptr2_q);

void add_elt(Queue** p2_q, int state, char* word);

void del_elt(Queue** p2_q);

void disp_q(Queue* p_q);

int empty_queue(Queue* p_q);

#endif
