#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include "automate.h"
#include "graph.h"
#include "file.h"


Automate* create_automate(int nb_st, char *alphab, int i_st, int* f_st, int nb_finals)
{
	Automate *autom = malloc(sizeof(Automate));
	autom->grph = create_graph(nb_st);
	autom->alphab = alphab;
	autom->init_st = i_st;
	autom->finals_st = f_st;
	autom->nb_finals = nb_finals;

	return autom;
}


void free_autom(Automate* autom)
{
	free_graph(autom->grph);
	free(autom);
}

int states_add(Automate* autom, int e1, char ch, int e2)
{
	int bool_alphb=0, i=0;
	while(autom->alphab[i] != '\0' && !bool_alphb)
	{
		if(autom->alphab[i] == ch)
		{
			bool_alphb = 1;
		}
		i++;
	}


	if( e1 < autom->grph->nb_head && e2 < autom->grph->nb_head && e1>=0 && e2>=0 && bool_alphb)
	{
		if(arc_exist(autom->grph, e1, ch, e2))
		{
			printf("Erreur\n");
			return -1;
		}
		else{
			add_arc(autom->grph, e1, ch, e2);
			return 1;
		}
	}
	else
	{
		printf("Erreur\n");
		return -1;
	}
}

void print_autom(Automate* autom)
{
	int i=0;
	printf("Init state= %d \n", autom->init_st);
	printf("Nb finals states= %d \n", autom->nb_finals);

	printf("{ ");
	for(i=0;i<autom->nb_finals;i++)
	{
		printf("%d ",autom->finals_st[i]);
	}
	printf("}\n");
	
	printf("Alphabet : { %s }\n",autom->alphab);

	print_Graph(autom->grph);

}

int word_in_alphabet(char* word, char* alphab)
{
	int i =0;
	while (word[i]!= '\0')
	{
		if(strchr(alphab,word[i]) == NULL)
		{
			return 0;
		}
		i++;
	}
	return 1;
}


int stateNextChar(Automate* autom, int s1, char e)
{
	Graph* g = autom->grph;
    Arc* ax = g->arcs[s1];
	int cnt = 1;
	int r=-1;
	while(ax != NULL && cnt)
	{
		if(ax->ch == e)
		{
			r = ax->ngbr;
			cnt = 0;
		}
		ax = ax->nxtA;
	}

	return r;

}



int accept(Automate* autom, char* word)
{
	int char_find=0, lenght_word = strlen(word), current_state=autom->init_st, i=0;

	if(word_in_alphabet(word, autom->alphab))
	{
		
		while(char_find < lenght_word)
		{
			current_state = stateNextChar(autom, current_state, word[i]);
			if(current_state == -1)
			{
				return 0;
			}
			else{
				char_find++;
				i++;
			}
		}

		for(i=0;i<autom->nb_finals;i++)
		{
			if(current_state == autom->finals_st[i])
				return 1;
		}

		return 0;
	}
	else{
		return 0;
	}

}


void Langage_croissant(Automate* autom, int profMax)
{
	Queue* file=NULL;
	Arc* acx;
	int i=0, bool_final_st=0, current_state = 0;
	init_queue(&file);

	add_elt(&file, current_state, "");

	while(empty_queue(file) == 0)
	{
		
		acx = autom->grph->arcs[current_state];
		while(acx != NULL)
		{
			for(i=0;i<autom->nb_finals;i++)
			{
				if(current_state == autom->finals_st[i])
					bool_final_st=1;
			}
			if(bool_final_st)
			{
				
			}
			add_elt(&file, acx->ngbr, acx->ch);
			acx = acx->nxtA;
		}

		
	}
}