#include <stdio.h>
#include <stdlib.h>
#include "graph.h"

int main()
{
    Graph* g = create_graph(3);
    
}
