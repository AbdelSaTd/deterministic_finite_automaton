#ifndef GRAPHE_H
#define GRAPHE_H

typedef struct Arc
{
	int ngbr;
	char ch;
	struct Arc* nxtA;
}Arc;

typedef struct Graph
{
	int nb_head;
	Arc** arcs;
}Graph;

Graph* create_graph(int nb_head);

void add_arc(Graph* g, int s1, char e, int s2);

int arc_exist(Graph* g, int s1, char e, int s2);

void print_Arc(int s1, Arc* a);

void print_Graph(Graph* g);

void rmv_arc(Graph* g, int s1, char e, int s2);

int transit(Graph* g, int s1, char e);

void free_graph(Graph* g);

#endif
